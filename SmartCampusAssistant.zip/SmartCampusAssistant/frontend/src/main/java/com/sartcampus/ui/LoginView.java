
package com.sartcampus.ui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class LoginView extends Application {

    @Override
    public void start(Stage stage) {
        Label title = new Label("Smart Campus Assistant");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        ComboBox<String> role = new ComboBox<>();
        role.getItems().addAll("Student", "Faculty");
        role.setPromptText("Select Role");

        TextField email = new TextField();
        email.setPromptText("Email");

        PasswordField password = new PasswordField();
        password.setPromptText("Password");

        Button login = new Button("Login");

        VBox root = new VBox(15, title, role, email, password, login);
        root.setAlignment(Pos.CENTER);

        stage.setScene(new Scene(root, 420, 380));
        stage.setTitle("Smart Campus");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
