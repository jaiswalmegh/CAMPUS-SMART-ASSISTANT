
package com.smartcampus;

import jakarta.persistence.*;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String password;
    private double attendance;
    private double grade;

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public double getAttendance() { return attendance; }
    public double getGrade() { return grade; }

    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setAttendance(double attendance) { this.attendance = attendance; }
    public void setGrade(double grade) { this.grade = grade; }
}
